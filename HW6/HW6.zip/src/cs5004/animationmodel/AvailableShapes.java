package cs5004.animationmodel;

/**
 * Enum to represent the shapes available to be created.
 */
public enum AvailableShapes {
  RECTANGLE, OVAL
}
